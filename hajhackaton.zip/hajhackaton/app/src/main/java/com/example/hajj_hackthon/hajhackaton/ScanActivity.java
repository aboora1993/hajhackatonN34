package com.example.hajj_hackthon.hajhackaton;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ScanActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Button button;
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_scan);
        button = (Button) findViewById(R.id.button_show);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RoundTrip();
            }
        });
    }

    public void RoundTrip() {

        Intent intent = new Intent(this, RoundTrip.class);
        startActivity(intent);
    }
    }

