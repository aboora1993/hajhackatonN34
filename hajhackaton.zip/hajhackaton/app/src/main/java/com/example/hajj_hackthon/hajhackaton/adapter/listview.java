package com.example.hajj_hackthon.hajhackaton.adapter;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import com.example.hajj_hackthon.hajhackaton.MainActivity;
import com.example.hajj_hackthon.hajhackaton.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class listview extends Activity {

    ListView listView;
    ArrayList<Integer> idIamages;
    ArrayList<String> nameList;
    MyAdapter myAdapter;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listview);
        listView = findViewById(R.id.list);
        idIamages = new ArrayList<Integer>(idIamages);
        nameList = new ArrayList<String>(nameList);
        idIamages = getListid();
        nameList= getNameList();
        myAdapter = new MyAdapter(listview.this,idIamages,nameList);
        listView.setAdapter(myAdapter);

    }

    /*

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        final ListView listView;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listview);
        listView = (ListView) findViewById(R.id.list);
        //ListView androidListView = (ListView) findViewById(R.id.list);
        String[] values = new String[] { "Flight", "Hotel", "Meeting",
                "Visiting", "Hotel", "Visiting", "Flight", "Hotel" };
        String[] values1 = new String[] { "Flight", "Hotel", "Meeting",
                "Visiting", "Hotel", "Visiting", "Flight", "Hotel" };
        int[] listviewImage = new int[]{
                R.drawable.ic_launcher_background, R.drawable.ic_launcher_background, R.drawable.ic_launcher_background, R.drawable.ic_launcher_background,
                R.drawable.ic_launcher_background, R.drawable.ic_launcher_background, R.drawable.ic_launcher_background, R.drawable.ic_launcher_background,
        };

        // Define a new Adapter
        // First parameter - Context
        // Second parameter - Layout for the row
        // Third parameter - ID of the TextView to which the data is written
        // Forth - the Array of data

        //List<HashMap<String, String>> aList = new ArrayList<HashMap<String, String>>();

       // for (int i = 0; i < 8; i++) {
         //   HashMap<String, Integer> hm = new HashMap<>();
          //  hm.put("listview_title", values[i]);
          //  hm.put("listview_discription", values1[i]);
          //  ///hm.put("listview_image", listviewImage[i]);
//     }

        String[] from = {"listview_image", "listview_title", "listview_discription"};
        int[] to = {R.id.listview_item_title, R.id.listview_item_short_description, R.id.listview_image};



        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, android.R.id.text1, values);
        //SimpleAdapter simpleAdapter = new SimpleAdapter(getBaseContext(), aList, R.layout.listview_activity, from, to);



        // Assign adapter to ListView
        listView.setAdapter(adapter);



    }
*/

    public ArrayList<Integer> getListid() {

        idIamages = new ArrayList<>();
        idIamages.add(R.drawable.ic_hotel_black_24dp);
        idIamages.add(R.drawable.ic_hotel_black_24dp);
        idIamages.add(R.drawable.ic_hotel_black_24dp);
        idIamages.add(R.drawable.ic_hotel_black_24dp);
        idIamages.add(R.drawable.ic_hotel_black_24dp);
        idIamages.add(R.drawable.ic_hotel_black_24dp);
        idIamages.add(R.drawable.ic_hotel_black_24dp);
        idIamages.add(R.drawable.ic_hotel_black_24dp);
        return idIamages;
    }

    public ArrayList<String> getNameList() {

        nameList = new ArrayList<>();
        nameList.add("Flight");
        nameList.add("Flight");
        nameList.add("Flight");
        nameList.add("Flight");
        nameList.add("Flight");
        nameList.add("Flight");
        nameList.add("Flight");
        nameList.add("Flight");
        return nameList;
    }




}





