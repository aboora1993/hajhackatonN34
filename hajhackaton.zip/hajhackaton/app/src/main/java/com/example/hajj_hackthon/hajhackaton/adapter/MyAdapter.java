package com.example.hajj_hackthon.hajhackaton.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.hajj_hackthon.hajhackaton.R;

import java.util.ArrayList;

public class MyAdapter extends BaseAdapter {


    private Context context;
    private ArrayList<Integer> listids;
    private ArrayList<String> namesList;

    public MyAdapter(Context context, ArrayList<Integer> listids, ArrayList<String> names) {
        this.context = context;
        this.listids = listids;
        this.namesList = names;
    }

    @Override
    public int getCount() {
        return namesList.size();
    }

    @Override
    public Object getItem(int position) {
        return namesList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        if(convertView==null)
        {
            convertView = View.inflate(context,R.layout.items_list ,null);
        }
        try {
            ImageView images = (ImageView) convertView.findViewById(R.id.listview_image);
            TextView text = (TextView) convertView.findViewById(R.id.textView);
            System.out.println("listids.get(position) = " + listids.get(position));
            images.setImageResource(listids.get(position));
            text.setText(namesList.get(position));

        } catch (Exception e) {

            e.printStackTrace();
        }

        return convertView;
    }
}
