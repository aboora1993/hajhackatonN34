package com.example.hajj_hackthon.hajhackaton;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.hajj_hackthon.hajhackaton.adapter.listview;

import java.util.ArrayList;

public class RoundTrip extends AppCompatActivity {
    /*private Context context;
    private ArrayList<Integer> ids;
    private ArrayList<String> names;

    public RoundTrip(Context context, ArrayList<Integer> ids, ArrayList<String> names) {
        this.context = context;
        this.ids = ids;
        this.names = names;
    }
    public int getCount(){
        return names.size();
    }
   @Override
    public Object getItem(int position){
        names.get(position);



   }
   @Override*/

    Button button;
    Button button1;
    Button button2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_round_trip);
        button = (Button) findViewById(R.id.button2);
        button1 = (Button) findViewById(R.id.button);
        button2 = (Button) findViewById(R.id.button4);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            listview();
            }
        });
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            RoundMap();
            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }
    public void RoundMap() {

        Intent intent = new Intent(this, RoundMap.class);
        startActivity(intent);
    }
    public void listview() {

        Intent intent = new Intent(this, listview.class);
        startActivity(intent);
    }

}
